package sample;


import java.util.Enumeration;



public interface Employee {

     boolean isLeaf();
     void add(Employee employee);
     void removeEmployee(Employee employee);
     Enumeration getSubordinates();
     String getName();
     double getSalary();
     double getSalaries();
     void print();
}
