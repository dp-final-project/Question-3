package sample;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

public class Employers_class implements Employee {


    String name;
    float salary;
    Vector subordinates;
    double sum;

    public Employers_class(String _name, float _salary) {
        name = _name;
        salary = _salary;
        subordinates = new Vector();
    }

    public double getSalary() {
        return salary;
    }
    public String getName() {
        return name;
    }

    public void add(Employee employee) {
        subordinates.addElement(employee);
    }

    public void removeEmployee(Employee employee) {
        subordinates.remove(employee);

    }

    public Enumeration getSubordinates() {
        Enumeration e = subordinates.elements();
        return e;
    }

    @Override
    public boolean isLeaf() {
        return false;
    }

    @Override
    public double getSalaries() {
        sum = getSalary();
        Iterator<Employee> employeeIterator = subordinates.iterator();

        while(employeeIterator.hasNext()){
            Employee employee = employeeIterator.next();
            sum += employee.getSalaries();
        }

        return sum;
    }


    public void print() {

        System.out.println("-------------");
        System.out.println("Name ="+getName());
        if(isLeaf()){
            System.out.println("Salary ="+getSalary());
        }else{
            System.out.println("Salary ="+getSalaries());

        }        System.out.println("-------------");

        Enumeration e = subordinates.elements();
        while(e.hasMoreElements()){
            Employee employee = (Employee) e.nextElement();
            employee.print();
        }


    }

}



