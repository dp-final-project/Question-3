package sample;


import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

import java.net.URL;
import java.util.Enumeration;
import java.util.ResourceBundle;



public class EmployeeViewController implements Initializable {

    Employee retEmp = null;

    TreeItem<String> selectedTreeItem;
    private String SelectedNode;
    @FXML TreeView treeView;
    @FXML ListView employeeList;
    @FXML Label individualSalaryLabel;
    @FXML Label salaryValue;
    @FXML Pane addNewEmp;
    @FXML Button addNew;
    @FXML TextField newEmpName;
    @FXML TextField newEmpSalary;
    Alert alert = new Alert(AlertType.INFORMATION);



    final static Employee CEO=new Employers_class("CEO", 200000);
    final static Employee VP_Marketing=new Employers_class("VP_Marketing", 150000);
    final static Employee VP_Production=new Employers_class("VP_Production", 150000);

    //VP_Marketing subordinates
    final static Employee salesMgr = new Employers_class("salesMgr", 100000);
    final static Employee advMgr  = new Employers_class("advMgr", 100000);

    //VP_production subordinates
    final static Employee prodMgr = new Employers_class("prodMgr", 100000);
    final static Employee shipMgr  = new Employers_class("shipMgr", 100000);

    TreeItem<String> root = new TreeItem<>(CEO.getName());





    @Override
    public void initialize(URL location, ResourceBundle resources) {

        treeView.setRoot(root);
        root.setExpanded(true);
        employeeList.getItems().add("       CEO");


        Employee sales_1=new Employee_class("sales-1", 50000);
        Employee sales_2=new Employee_class("sales-2", 50000);
        Employee sales_3=new Employee_class("sales-3", 50000);

        salesMgr.add(sales_1);
        salesMgr.add(sales_2);
        salesMgr.add(sales_3);

        //advertisement manager subordinates
        Employee secy=new Employee_class("secy", 50000);
        advMgr.add(secy);

        //production manager subordinates
        Employee manu_1=new Employee_class("manu-1", 50000);
        Employee manu_2=new Employee_class("manu-2", 50000);
        Employee manu_3=new Employee_class("manu-3", 50000);

        prodMgr.add(manu_1);
        prodMgr.add(manu_2);
        prodMgr.add(manu_3);

        //ship manager subordinates
        Employee ship_1=new Employee_class("ship-1", 50000);
        Employee ship_2=new Employee_class("ship-2", 50000);

        shipMgr.add(ship_1);
        shipMgr.add(ship_2);

        VP_Marketing.add(salesMgr);
        VP_Marketing.add(advMgr);

        VP_Production.add(prodMgr);
        VP_Production.add(shipMgr);

        CEO.add(VP_Marketing);
        CEO.add(VP_Production);
        getTreeStructure(root, CEO);
        getEmployeeList(CEO);
        addNewEmp.setVisible(false);

        final ContextMenu contextMenu = new ContextMenu();
        MenuItem AddNewEmployee = new MenuItem("Add new Employee");
        MenuItem remove = new MenuItem("Remove Employee");

        contextMenu.getItems().addAll(AddNewEmployee, remove);
        AddNewEmployee.setOnAction(event -> {
            Employee bossForNew  = getEmployee(SelectedNode, CEO);
            if(bossForNew.isLeaf()){
                addNewEmp.setVisible(false);
                showAlert("New employees can only be added under employers(Bosses).");

            }else{
                addNewEmp.setVisible(true);
            }
        });

        remove.setOnAction(event -> {
            Employee selectedEmployee = getEmployee(SelectedNode, CEO);

            String parentStr;
            Employee parentEmployee;
            if (selectedEmployee.getName() != "CEO") {
                parentStr = selectedTreeItem.getParent().getValue();
                parentEmployee = getEmployee(parentStr, CEO);
            }else{
                parentEmployee = CEO;
            }
            if((selectedEmployee.isLeaf()) || (SelectedNode != "CEO" && SelectedNode != "VP_Marketing" && SelectedNode != "VP_Production")){
                parentEmployee.removeEmployee(selectedEmployee);
                selectedTreeItem.getParent().getChildren().removeAll(selectedTreeItem);

                employeeList.getItems().clear();
                employeeList.getItems().add("CEO");
                getEmployeeList(CEO);

            }else{
                showAlert("Employers(Bosses) can not be removed.");
            }
        });

        treeView.setContextMenu(contextMenu);

        EventHandler<MouseEvent> mouseEventHandle = (MouseEvent event)->{
            MouseButton button = event.getButton();

            if(button==MouseButton.PRIMARY){
                Node node = event.getPickResult().getIntersectedNode();
                //Accept clicks only on node cells and not on empty spaces of the TreeView
                if(node instanceof Text || (node instanceof TreeCell && ((TreeCell) node).getText() != null)) {
                    String name = (String) ((TreeItem) treeView.getSelectionModel().getSelectedItem()).getValue();
                    //System.out.println(name + " selected node");
                    handleSalary(name);
                }
           }else if(button == MouseButton.SECONDARY){
                getNode(event, treeView);
            }
        };

        treeView.addEventHandler(MouseEvent.MOUSE_CLICKED, mouseEventHandle);

        employeeList.setOnMouseClicked(event -> {
            String empFromList = (String) employeeList.getSelectionModel().getSelectedItem();
            handleSalary(empFromList.trim());

        });
    }


    //iterate through employees and draw the tree
    public void getTreeStructure(TreeItem<String> pnode, Employee emp) {
        TreeItem<String> node;

        Enumeration e = emp.getSubordinates();
        while (e.hasMoreElements()) {
            Employee newEmp = (Employee) e.nextElement();
            node = new TreeItem<>(newEmp.getName());
            pnode.getChildren().add(node);
            getTreeStructure(node, newEmp);
        }
    }


    public void getEmployeeList(Employee emp) {

        Enumeration e = emp.getSubordinates();
        while (e.hasMoreElements()) {
            Employee newEmp = (Employee) e.nextElement();
            employeeList.getItems().add("   " + newEmp.getName());
            getEmployeeList(newEmp);
        }
    }



    //using the given employee from the tree get its salary
    private void handleSalary(String name) {

            Employee emp = getEmployee(name, CEO);
            //System.out.println("Node clicked: "+ emp.getName());
            double Salary = emp.getSalaries();
            double individualSalary = emp.getSalary();
            salaryValue.setText(Double.toString(Salary));
            individualSalaryLabel.setText(Double.toString(individualSalary));
            //System.out.println("Node clicked: "+ Double.toString(Salary));

    }



    //Identifies the selected node
    private void getNode(MouseEvent event, TreeView<String> treeView) {
        Node node = event.getPickResult().getIntersectedNode();
        //Accept clicks only on node cells and not on empty spaces of the TreeView
        if(node instanceof Text || (node instanceof TreeCell && ((TreeCell) node).getText() != null)){
            selectedTreeItem = treeView.getSelectionModel().getSelectedItem();
            //System.out.println("selected tree item" + selectedTreeItem);
            String name = (String)((TreeItem)treeView.getSelectionModel().getSelectedItem()).getValue();
            SelectedNode = name;
        }
    }





    //adds the new employee to the tree
    public void handelNewEmployee() {
        try {
            Employee bossForNew = getEmployee(SelectedNode, CEO);
            String name = newEmpName.getText();

            float salary = Float.parseFloat(String.valueOf(newEmpSalary.getText()));
            Employee newEmployee = new Employers_class(name, salary);
            bossForNew.add(newEmployee);

            TreeItem newEmployeeItem = new TreeItem<>(newEmployee.getName());
            selectedTreeItem.getChildren().add(newEmployeeItem);
            employeeList.getItems().clear();
            employeeList.getItems().add("CEO");
            getEmployeeList(CEO);

            showAlert("New employee have been added.");

            addNewEmp.setVisible(false);
            newEmpName.setText("");
            newEmpSalary.setText("");

        }catch (Exception e){
            showAlert("Salary should have numeric value.");
        }
    }



    //Iterate through the given employee's subordinates to find the employee with the given name
    public Employee getEmployee(String name, Employee root) {

        if(root.getName().contentEquals(name)){
            return root;
        }
        Enumeration e = root.getSubordinates();
        while(e.hasMoreElements()){
            Employee employee = (Employee) e.nextElement();
            //System.out.println(employee.getName());
            if(employee.getName().contentEquals(name)){
                retEmp =  employee;
                //System.out.println(retEmp.getName() +"return employee ");
                return retEmp;
            }else{

                getEmployee(name, employee);
            }
        }

       return retEmp;
   }

   public void showAlert(String message){

       alert.setTitle(null);
       alert.setHeaderText(null);
       alert.setContentText(message);
       alert.showAndWait();
   }

}

