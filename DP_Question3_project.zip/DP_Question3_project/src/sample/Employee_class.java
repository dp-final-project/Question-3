package sample;

import java.util.Enumeration;
import java.util.Vector;


public class Employee_class implements Employee{



    String name; float salary;
    Vector subordinates;
    public Employee_class(String name, float salary) {
        this.name = name;
        this.salary = salary;
        subordinates = new Vector();
    }

    public double getSalary() {
        return salary;
    }


    public String getName() {
        return name;
    }



    public void add(Employee employee) {}

    public void removeEmployee(Employee e) {}

    public Enumeration getSubordinates() {
        Enumeration e = subordinates.elements();
        return e;
    }

    @Override
    public boolean isLeaf() {
        return true;
    }

    @Override
    public double getSalaries() {
        return salary;
    }


    public void print() {
        System.out.println("-------------");
        System.out.println("Name ="+getName());
        System.out.println("Salary ="+getSalary());
        System.out.println("-------------");

    }
}


